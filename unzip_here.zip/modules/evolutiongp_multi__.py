import numpy as np
from numpy.lib.arraysetops import unique
from simpful import *
from simpful import proba_generator
import operator
import random
from random import randint
from difflib import SequenceMatcher
from operator import itemgetter
import regex as re
import logging
import statistics

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s:%(name)s:%(message)s')
file_handler = logging.FileHandler('sample.log')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

def resizer(winning_rules):
    if len(winning_rules[0]) != len(winning_rules[1]):
        
        # choose shortest model as template if random size proba < 0.5
        random_sizer = random.random()
        if random_sizer<0.3:    
            length_keeper = {
                "length_of_one": len(winning_rules[0]),
                "length_of_two": len(winning_rules[1])
            }
            shortest_individual = min(length_keeper, key=length_keeper.get)
            longest_individual = max(winning_rules, key=len)
            longest_individual_resized = longest_individual[0:length_keeper.get(
                shortest_individual)]
            winning_rules = [winning_rules[0], longest_individual_resized]
            return winning_rules
        else:

            shortest_individual = min(winning_rules, key=len)
            longest_individual = max(winning_rules, key=len)
            new_indiv = []
            for i in range(len(longest_individual)):
                if len(new_indiv)<len(shortest_individual):
                    new_indiv.append(shortest_individual[i])
                else:
                    random_rule_selection = random.randint(0, len(shortest_individual)-1)
                    new_indiv.append(shortest_individual[random_rule_selection])
            winning_rules = [new_indiv, longest_individual]
            
            return winning_rules

    else:
        return winning_rules

def proba_generator_no_normal(n):
    """
    Global method for generating a list of probabilities (uniformly distributed).

    Args:
        n ([integer]): the length of the list containing probabilities to be created.

    Returns:
        [list]: a list of probabilities.
    """
    list_of_random_floats = np.random.random(n)
    return list_of_random_floats


def split_list(a_list):
    half = len(a_list)//2
    return a_list[:half], a_list[half:]

def similar(a, b):
    return SequenceMatcher(None, a, b).ratio()

def tokenizer(some_rule):
    re.findall(r"\w+(?=\sIS)|(?<=IS\s)\w+", some_rule)

def findMax(data):
    all_ele = []
    for d in data:
        for t in d.items():
            all_ele.append(t)
    
    return max(all_ele, key=lambda item: item[1])

def ruleIndicator(selected, elements_probas):
    for rule, ruleholder in enumerate(elements_probas):
        for key, value in ruleholder.items():
            if key == selected[0] and value == selected[1]:
                break
    return rule



def Diff(li1, li2):
    li_dif = [i for i in li1 + li2 if i not in li1 or i not in li2]
    return li_dif


class FuzzyEvolution:

    """ Assumes that you cluster first and have a matrix with samples and features. 
        Furthermore, you needs to include a list with variable names and consequents. """
    

    @staticmethod
    def mutation(crossover_result, mutation_thresh, all_vars):

        try:

            crossover_result = crossover_result[1]

            all_vars = all_vars

            mutation_thresh = mutation_thresh

            mutation_proba = random.random()

            if mutation_proba > mutation_thresh:

                #retrieve vars
                antecedents = [preparse(ant) for ant in crossover_result]
                finalcheck = [re.findall(r"\w+(?=\sIS)", ant)
                            for ant in antecedents]

                elements_probas = []

                for ele in finalcheck:
                    probas = proba_generator_no_normal(len(ele))
                    elements_probas.append(dict(zip(ele, probas)))

                selected = findMax(elements_probas)

                selected_rule = ruleIndicator(selected, elements_probas)
                current_vars = [list(item.keys()) for item in elements_probas]
                flatten = [item for sublist in current_vars for item in sublist]
                unique_vars = list(set(flatten))
                choosable_vars = Diff(all_vars, unique_vars)
                if not choosable_vars:
                    return None
                else:
                        
                    chosen_var = random.choice(choosable_vars)
                    mutated_rules = []

                    for rule_numb, rule in enumerate(crossover_result):
                        if rule_numb == selected_rule:
                            changed_rule = rule.replace(selected[0], chosen_var)
                            mutated_rules.append(changed_rule)
                        else:
                            mutated_rules.append(rule)

                    antecedents_mut = [preparse(ant) for ant in mutated_rules]
                    var_check_mut = [re.findall(r"\w+(?=\sIS)", ant)
                                    for ant in antecedents_mut]

                    flatten_crossover = [
                        item for sublist in var_check_mut for item in sublist]
                    unique_vars_cross = list(set(flatten_crossover))

                    final_result = [unique_vars_cross, mutated_rules]

                    return final_result
                
        except ValueError:
            return None


    @staticmethod
    def crossover(sorted_ranking, sorted_dict, fittest_parent_threshold=None):

        crossover_proba = random.random()
        final_winner = None

        if crossover_proba <= 0.0001:
            pass
        
        else:
            try:

                
                # Tournament (one go for now)
                tournament_size = 2

                    # individual 1 that will be selected from 2 fighters from the population
                k = random.sample(range(1, len(sorted_ranking)-1), tournament_size)
                
                    # Get individuals and make them fight
                to_battle = [sorted_dict.get(i) for i in k]
                winner = [fighter[2] for fighter in to_battle]
                complexity = [complexity[3] for complexity in to_battle]
                comp_complexity = [2*comp[0]*comp[1] for comp in complexity]

                # check fitness values and retrieve winner
                if winner[0] != winner[1]:
                    index, value = max(enumerate(winner),
                                    key=operator.itemgetter(1))
                else:   # else handles complexity case
                    index, value = min(enumerate(comp_complexity),
                                    key=operator.itemgetter(1))
                
                    # extract parent 1, mainly for debugging purposes
                parent_one = (index, value)
                original_index = None
                if index == 0:
                    original_index = k[0]
                else:
                    original_index = k[1]

                    # individual 2 that will be selected from 2 fighters from the population
                match = []
                while len(match)<(tournament_size):
                    l = random.sample(range(1, len(sorted_ranking)-1), 1)
                    if l not in k and l not in match:
                        match.append(l)
                match = [item for sublist in match for item in sublist]

                    # Get individuals and make them fight
                to_battle_ = [sorted_dict.get(i) for i in match]

                winner_ = [fighter[2] for fighter in to_battle_]
                complexity_ = [complexity[3] for complexity in to_battle_]
                comp_complexity_ = [2*comp[0]*comp[1] for comp in complexity_]

                # check fitness values, retrieve winner
                if winner_[0] != winner_[1]:
                    index_, value_ = max(enumerate(winner_),
                                        key=operator.itemgetter(1))
                else:
                    index_, value_ = min(enumerate(comp_complexity_),
                                        key=operator.itemgetter(1))
                original_index_ = None
                if index_ == 0:
                    original_index_ = match[0]
                else:
                    original_index_ = match[1]
                parent_two = (index_, value_)

                parents = [original_index, original_index_]
                

                winners = [sorted_dict.get(i) for i in parents]

                # extract winners rules
                winning_rules = []
                length_of_parents = []
                fitness_values = []

                # check syntax of parents
                for models in winners:
                    length_of_parents.append(len(models[0].raw_rules))


                for model in winners:
                    winning_rules.append(model[1])
                    fitness_values.append(model[2])

            
                winning_rules = resizer(winning_rules)


                winning_rules = [x for _, x in sorted(zip(fitness_values, winning_rules))]

                # check for similarity
                rules_to_check = []
                for model in winning_rules:
                    for rule in model:
                        rules_to_check.append(preparse(rule))
                
                rules_to_check_split = split_list(rules_to_check)
                rules_to_check = zip(rules_to_check_split[0], rules_to_check_split[1])

                similarities = []
                for a, b in rules_to_check:
                    similarities.append(similar(a, b))

                # rule to substitute
                rules_to_check_ = zip(
                    similarities, rules_to_check_split[0], rules_to_check_split[1])

                similarity_thresh = 0.9
                crossover_type = 1
                adjusted_rules_parent = []
                adjusted_rules_parent_ = []
                counter = 0
                for sim, r, s, in rules_to_check_:
                    if sim < similarity_thresh and crossover_type > counter:
                        counter += 1
                        adjusted_rules_parent.append(s)
                        adjusted_rules_parent_.append(r)
                    else:
                        adjusted_rules_parent.append(r)
                        adjusted_rules_parent_.append(s)
                    
                    # winning rules is sorted
                adjusted_rules_parent_fixed = [
                    'IF ' + rule + ' THEN P(OUTCOME IS DEATH)=None, P(OUTCOME IS ALIVE)=None' for rule in adjusted_rules_parent_]
                adjusted_rules_parentfixed = [
                    'IF ' + rule + ' THEN P(OUTCOME IS DEATH)=None, P(OUTCOME IS ALIVE)=None' for rule in adjusted_rules_parent]

                    # select rules (model rules) to keep by choosing either fittest parent with proba p or other parent with 1 - p
                    # Crossover procedure
                    # uniformly generate a probability between 0 and 1 (if larger than 0.2 crossover happens)
                    # for these individuals, otherwise it won't
                
                if fittest_parent_threshold is not None:
                    fittest_parent_threshold = fittest_parent_threshold
                else:
                    fittest_parent_threshold = 0.8
                
                    # Generate a random proba to decide if we choose fittest parent or not
                parent_chooser = random.random()

                    # if generate proba is bigger then threshold (tournament proba) the weakest parent is chosen

                if parent_chooser > fittest_parent_threshold:
                    final_winner = adjusted_rules_parentfixed
                else:
                    final_winner = adjusted_rules_parent_fixed
                
                if final_winner is None:
                    return None
                
                antecedents_cross = [preparse(ant) for ant in final_winner]
                var_check_cross = [re.findall(r"\w+(?=\sIS)", ant)
                            for ant in antecedents_cross]
                
                cluster_check = [re.findall(r"cluster\d", ant)
                                for ant in antecedents_cross]
                processed_cluster = [item for sublist in cluster_check for item in sublist]
                processed_cluster = list(dict.fromkeys(processed_cluster))
                digits = [re.findall(r"\d", cluster)
                        for cluster in processed_cluster]
                flatten_digits = [
                    item for sublist in digits for item in sublist]
                
                ordered_clusters = list(dict.fromkeys(flatten_digits))
                new_rules = []
                for index, (rule, cluster) in enumerate(zip(final_winner, processed_cluster)):
                    new_rules.append(rule.replace(cluster, 'cluster{}'.format(index)))


                flatten_crossover = [item for sublist in var_check_cross for item in sublist]
                unique_vars_cross = list(set(flatten_crossover))

                final_result = [unique_vars_cross, new_rules]

                return final_result
            
            except ValueError:
                return None
        

    
    @ staticmethod
    def evaluator(object, rules_=None):
        errors = []
        if rules_ is None:
            rules = object.generate_proba_rules(select=True)
        else:
            rules = rules_
        object.add_proba_rules(rules)
        object.X_reformatter()
        object.add_linguistic_variables()
        try:
            preds = object.predict_pfs()
        except ValueError:
            errors.append(object.p_rules)
            errors.append(object.probas_)
            
        accuracy = object.evaluate_fitness()
#        logger.debug('Fitness: {}'.format(accuracy))
        rules = object.p_rules
        seed = object.seed
        numb_clusters = (len(rules))
        conditions = 0
        for rule in object._rules:
            conditions += len(re.findall(r"c\.", str(rule)))
        complexity_info = (conditions, len(object._rules))
        return preds, accuracy, rules, seed, numb_clusters, complexity_info, errors

    @staticmethod
    def initialisor(population_, all_vars, X, X_T, y, y_test, consequents, thresh = None, fittest_parent_threshold=None):
        
        # Handling no thresh given
        if thresh is None:
            thresh = len(all_vars)-1

        # for internal calls
        X = X
        X_T= X_T
        y = y
        y_test = y_test
        consequents = consequents
        fittest_parent_threshold = fittest_parent_threshold
        all_of_em = all_vars

        # Create Probabilistic Fuzzy System
        population_ = population_
        population = [ProbaFuzzySystem(consequents=consequents, all_var_names=all_of_em, X=X, X_test=X_T, y=y, y_test=y_test, threshold=thresh,
                                    pred_test=True, _return_class=True, generateprobas=False) for i in range(population_)]
        


        # Initialize arguments of interest
        all_preds = []
        all_accuracies = []
        all_rules = []
        complexity_info = []
        clustering_seeds = []
        number_of_clusters = []

        # only errors spotted until now are zero division errors due to nans. Handled appropriately.
        errors = []

        # Evaluate the population and save args of interest
        for object in population:
            
            preds, accuracy, rules, seed, num_clusters, comp_info, errors = FuzzyEvolution.evaluator(object)
            all_preds.append(preds)
            all_accuracies.append(accuracy)
            all_rules.append(rules)
            complexity_info.append(comp_info)
            number_of_clusters.append(num_clusters)
            clustering_seeds.append(seed)
            errors.append(errors)
        
        logger.debug('Fitness: {}'.format(all_accuracies))
        horizon = list(range(len(population)))
        ranking = zip(horizon, population, all_rules, all_accuracies,
                    complexity_info, number_of_clusters)
        sorted_ranking = sorted(ranking, key=lambda x: x[3], reverse=True)
        sorted_dict = {models[0]: models[1:] for models in sorted_ranking}
        

        # Keep best n individuals
        surviving_individuals = {}
        surviving_individuals[1000] = sorted_dict.get(sorted_ranking[0][0])

        # Start of crossover, we take length of population as
        # not all crossover will return a child (recombination proba set to 0.8)
        crossover_results = []
        mutation_results = []

        for i in range(len(population)):
            child = FuzzyEvolution.crossover(
                sorted_ranking=sorted_ranking, sorted_dict=sorted_dict)

            if child is None:
                continue

            weirdchild = FuzzyEvolution.mutation(
                child, mutation_thresh=0.75, all_vars=all_of_em)

            if weirdchild is None and child is not None:
                crossover_results.append(child)
            if child is not None and weirdchild is not None:
                mutation_results.append(weirdchild)

        genes = crossover_results + mutation_results
        try:
            average_fitness = statistics.mean(all_accuracies)
        except statistics.StatisticsError:
            pass
        pop = len(population) + len(surviving_individuals)

        return genes, surviving_individuals, average_fitness, pop
    
    @staticmethod
    def gp_evolve(genes, all_vars, X, X_T, y, y_test, consequents, surviving_individuals):
        
        # elites
        elites = surviving_individuals

        # for internal calls
        X = X
        X_T = X_T
        y = y
        y_test = y_test
        consequents = consequents
        all_of_em = all_vars
        
        child_population = [ProbaFuzzySystem(consequents=consequents, unique_vars=unique_vars, all_var_names=all_of_em,
                                             X=X, X_test=X_T, y=y, y_test=y_test, pred_test=True, _return_class=True,
                                             generateprobas=False, numb_rules=len(rule_base)) for unique_vars, rule_base in genes]


        # Initialize arguments of interest
        all_preds = []
        all_accuracies = []
        complexity_info = []
        clustering_seeds = []
        all_rules = [item[1] for item in genes]

        # only errors spotted until now are zero division errors due to nans. Handled appropriately.
        errors = []

        # Evaluate the population and save args of interest
        for i, object in enumerate(child_population):
            rules = genes[i][1]
            preds, accuracy, rules, seed, num_clusters, comp_info, errors = FuzzyEvolution.evaluator(
                object, rules)
            all_preds.append(preds)
            all_accuracies.append(accuracy)
            all_rules.append(rules)
            complexity_info.append(comp_info)
            clustering_seeds.append(seed)
            errors.append(errors)

        logger.debug('Fitness: {}'.format(all_accuracies))
        horizon = list(range(len(child_population)))
        ranking = zip(horizon, child_population, all_rules,
                    all_accuracies, complexity_info)
        sorted_ranking = sorted(ranking, key=lambda x: x[3], reverse=True)
        sorted_dict = {models[0]: models[1:] for models in sorted_ranking}
        elites[len(sorted_dict)] = elites.pop(1000)
        sorted_dict.update(elites)

        keys, values = sorted_dict.keys(), sorted_dict.values()

        score_id = []
        for key, value in zip(keys, values):
            score_id.append((key, value[2]))
        
        id_best_indiv = max(score_id, key=itemgetter(1))[0]

        # Keep best n individuals
        # Keep best n individuals
        surviving_individuals = {}
        surviving_individuals[1000] = sorted_dict.get(id_best_indiv)

        # Start of crossover, we take length of population as
        # not all crossover will return a child (recombination proba set to 0.8)
        crossover_results = []
        mutation_results = []


        # bug here, this population doesnt contain rules yet. Going to sleep!
        for i in range(len(child_population)):
            child = FuzzyEvolution.crossover(
                sorted_ranking=sorted_ranking, sorted_dict=sorted_dict)

            if child is None:
                continue

            weirdchild = FuzzyEvolution.mutation(
                child, mutation_thresh=0.75, all_vars=all_of_em)

            if weirdchild is None and child is not None:
                crossover_results.append(child)
            if child is not None and weirdchild is not None:
                mutation_results.append(weirdchild)

        genes = crossover_results + mutation_results
        try:
            average_fitness = statistics.mean(all_accuracies)
        except statistics.StatisticsError:
            pass
        pop = len(child_population) + len(surviving_individuals)

        return genes, surviving_individuals, average_fitness, pop

    @staticmethod
    def gp_evaluate(genes, all_vars, X, X_T, y, y_test, consequents, surviving_individuals):

        elites = surviving_individuals

        # for internal calls
        X = X
        X_T = X_T
        y = y
        y_test = y_test
        consequents = consequents
        all_of_em = all_vars

        child_population = [ProbaFuzzySystem(consequents=consequents, unique_vars=unique_vars, all_var_names=all_of_em,
                                             X=X, X_test=X_T, y=y, y_test=y_test, pred_test=True, _return_class=True,
                                             generateprobas=False, numb_rules=len(rule_base)) for unique_vars, rule_base in genes]

        # Initialize arguments of interest
        all_preds = []
        all_accuracies = []
        complexity_info = []
        clustering_seeds = []
        all_rules = [item[1] for item in genes]

        # only errors spotted until now are zero division errors due to nans. Handled appropriately.
        errors = []

        # Evaluate the population and save args of interest
        for i, object in enumerate(child_population):
            rules = genes[i][1]
            preds, accuracy, rules, seed, num_clusters, comp_info, errors = FuzzyEvolution.evaluator(
                object, rules)
            all_preds.append(preds)
            all_accuracies.append(accuracy)
            all_rules.append(rules)
            complexity_info.append(comp_info)
            clustering_seeds.append(seed)
            errors.append(errors)

        logger.debug('Fitness: {}'.format(all_accuracies))
        horizon = list(range(len(child_population)))
        ranking = zip(horizon, child_population, all_rules,
                      all_accuracies, complexity_info)
        sorted_ranking = sorted(ranking, key=lambda x: x[3], reverse=True)
        sorted_dict = {models[0]: models[1:] for models in sorted_ranking}
        elites[len(sorted_dict)] = elites.pop(1000)
        sorted_dict.update(elites)

        keys, values = sorted_dict.keys(), sorted_dict.values()

        score_id = []
        for key, value in zip(keys, values):
            score_id.append((key, value[2]))

        id_best_indiv = max(score_id, key=itemgetter(1))[0]



        # Keep best n individuals
        surviving_individuals = sorted_dict.get(id_best_indiv)
        try:
            average_fitness = statistics.mean(all_accuracies)
        except statistics.StatisticsError:
            pass
        pop = len(child_population) + len(surviving_individuals)


        return surviving_individuals, average_fitness, pop
